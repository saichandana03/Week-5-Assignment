# HelloWorld Django App

## Setup and Run

- Clone the repository
- Navigate to the project directory
- Run `python manage.py runserver`
- Access the app at `http://localhost:8000/hello/`
